function F = NearestTightFrame(D);

%----------------------------------------------------%
%Get a tight frame nearest to the input
%----------------------------------------------------%
[d N] = size(D);
tightParam = sqrt(N/d);

frameoperator = D*D';
Dsqrt = sqrtm(frameoperator);
Dinvsqrt = pinv(Dsqrt);
Dtight = tightParam*Dinvsqrt*D;

F = Dtight;
%----------------------------------------------------%