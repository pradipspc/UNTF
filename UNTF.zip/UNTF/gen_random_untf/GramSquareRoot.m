function F = GramSquareRoot(G, d);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find a matrix F: dXN such that F'*F=G
% G hermittian matrix == Gram matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[N n]=size(G);

%reduce rank back to d
[U, S, V]=svd(G);
S(d+1:end, 1+d:end)=0;
G = U*S*V';

%normalize Gram
G = diag(1./sqrt(diag(G)))*G*diag(1./sqrt(diag(G)));

%check feasibility
E = eig(G);
E = real(E);
nonfeasible = length(find(E<-1e-4));

if nonfeasible %happens very rarely
    disp([' NON-FEASIBLE!!!!']);   
    D = [];
else    
    [U,S,V]=svd(G);
    D = sqrt(S(1:d,1:d))*U(:,1:d)';
    D = normc(D);
end

F = D;