function A = ConstructIncoUNTF(A, MAX_ITER);

disp('BUILD PROPOSED INCOHERENT UNTF...')

[d N] = size(A);
mg = 1/sqrt(d); %coherence bound

saveA = A;
A = NearestTightFrame(A);
for k=1:1:MAX_ITER 
    A = normc(A); %normalize columns of A
    G = A'*A; %compute Gram matrix          
    %
    Gp = GramProcessing(G, d); %Bound coherence through the Gram matrix
    A = GramSquareRoot(Gp,d);
    %
    A = NearestTightFrame(A); %Find nearest tight frame
end

disp([' (Total Iterations = ', num2str(k), ')']);  


