function Gp = GramProcessing(G, d);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% G is the Gram matrix of a dXN frame
% Bound the Gram matrix entries to reduce
% correlation of frame elements
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BOUND = 1/sqrt(d);

N = size(G, 1);
Gsave = G;
%GRAM MATRIX PROCESSING
H = 10*eye(N);
G = G+H;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
absG = abs(G);
pos1 = find((absG<10)&(absG>=BOUND));    
Gmg = ones(N,N)*BOUND;
G(pos1) = Gmg(pos1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Gsign = ones(N,N);
Gsign(pos1) = sign(Gsave(pos1));
Gp = Gsign.*G;
Gp = Gp-H;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    
