clc;clear;close all;
addpath('../');
defpaper;

%% nmse omp bp dense nn
% fig = openfig('bin_omp_nmse.fig');
fig = openfig('UNTF_BP_all_trunc.fig');


% hLegend = findobj(fig, 'Type', 'Legend');
%get text
% hLegend.String

hLines = findobj(fig, 'Type', 'Line');

x1 = get(hLines,'XData');
y1 = get(hLines,'YData');

% h1 = figure(3);
% colorBuf = {'r+-','y*-','go-'};
% legendName = {'OMP','BP','Dense DNN'};
% plotOrder = [1,3,2]';
% legend1 = {};
% for i=1:length(x1)
%     j = plotOrder(i);
%     plot(x1{j},10.^(y1{j}/10),colorBuf{j});hold on;
%     legend1 = [legend1;legendName{j}];
% end
% xlabel('Sparsity');ylabel('NMSE');grid on;
% legend(legend1,'location','best','FontSize',14);
% 
% saveas(h1,'nmse_omp_bp_Dense_normal.fig');
% saveas(h1,'nmse_omp_bp_Dense_normal.eps','epsc');
for i=1:4
    yy_untf{i} = y1{10-2*i};
    yy_gauss{i} = y1{9-2*i};
end
% 
% yy_gaus = y1{8:-2:2};
% yy_untf = y1{7:-2:1};

nLoops = 4;
pBuf = [11,13,17,19]';


colors = 'rk';
markers1 = {'x','<','p','+'};
markers2 = {'*','>','s','o'};

legendNames = {'Gaussian','UNTF'};
legend1 = cell(nLoops*2,1);

set(gcf, 'Position',  [100, 100, 1200, 700])
h1 = figure(1);


for ii=1:nLoops
    p = pBuf(ii);
    
%     pause(4);
    plot(yy_gauss{ii},strcat('--',colors(2),markers2{ii}),'MarkerIndices', 1:2:length(yy_gauss{ii}));hold on;
    plot(yy_untf{ii},strcat('-',colors(1),markers1{ii}),'MarkerIndices', 1:2:length(yy_untf{ii}));

    %     name1 = {};
    %     name2 = {strcat(num2str(p),legendNames{2})};
    %     legend1 = {legend1;Name1{ii}};
    
%     legend1{2*(ii-1)+1} = strcat(legendNames{1},'-',num2str(p*(p-1)/2),'x',num2str(p^2));
%     legend1{2*(ii-1)+2} = strcat(legendNames{2},'-',num2str(p*(p-1)/2),'x',num2str(p^2));

    
    legend1{2*(ii-1)+1} = strcat(legendNames{1},'-',num2str(p^2),'x',num2str(2*p^2));
    legend1{2*(ii-1)+2} = strcat(legendNames{2},'-',num2str(p^2),'x',num2str(2*p^2));
end
figure(1);
ylabel('NMSE','FontSize',14)
xlabel('sparsity','FontSize',14)
% title('BP performance');
ylim([0,0.05])
grid on;
legend(legend1,'Location','Best','FontSize',14,'FontWeight','bold');

% saveas(h1,'bin_omp_nmse.fig');
% saveas(h1,'bin_omp_nmse.eps','epsc');

